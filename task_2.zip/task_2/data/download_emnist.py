import tensorflow_datasets as tfds


def load_mnist():
    (train, test), info = tfds.load('mnist', split=[
        'train', 'test'], as_supervised=True, with_info=True)
    return train, test


def load_emnist():
    (train, test), info = tfds.load('emnist/byclass',
                                    split=['train', 'test'], as_supervised=True, with_info=True)
    return train, test
    # this part of the code extracts emnist datasets
