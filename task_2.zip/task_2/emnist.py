import os
import numpy as np
from tensorflow.keras.models import load_model
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import filedialog, Label, Button
import tensorflow_datasets as tfds

# Load both EMNIST and MNIST label decoders
emnist_builder = tfds.builder('emnist/balanced')
emnist_builder.download_and_prepare()
emnist_decoder = emnist_builder.info.features['label']

mnist_builder = tfds.builder('mnist')
mnist_builder.download_and_prepare()
mnist_decoder = mnist_builder.info.features['label']

# Load trained model
model = load_model("emnist_cnn_model.h5")


def preprocess_image(img_path, is_mnist=False):
    img = Image.open(img_path).convert('L')   # Grayscale
    img = img.resize((28, 28))                # Resize to 28x28
    img = np.array(img).astype('float32') / 255.0

    if not is_mnist:
        # EMNIST format: transpose + flip
        img = np.transpose(img)
        img = np.fliplr(img)

    img = np.expand_dims(img, axis=-1)        # (28, 28, 1)
    img = np.expand_dims(img, axis=0)         # (1, 28, 28, 1)
    return img


def predict_image():
    file_path = filedialog.askopenfilename()
    if not file_path:
        return

    # Show uploaded image
    display_img = Image.open(file_path).resize((100, 100))
    display_img_tk = ImageTk.PhotoImage(display_img)
    image_label.config(image=display_img_tk)
    image_label.image = display_img_tk

    # Try both MNIST and EMNIST preprocessing
    for dataset_type in ['MNIST', 'EMNIST']:
        is_mnist = (dataset_type == 'MNIST')
        processed = preprocess_image(file_path, is_mnist)
        prediction = model.predict(processed)
        predicted_label = np.argmax(prediction)
        confidence = np.max(prediction)

        if is_mnist and predicted_label < 10:
            # MNIST digit prediction
            predicted_char = mnist_decoder.int2str(predicted_label)
            result_text = f"Prediction: {predicted_char} (Digit, Confidence: {confidence:.2f})"
            break
        elif not is_mnist and predicted_label >= 10:
            # EMNIST letter prediction
            if predicted_label < 36:
                # Uppercase letters (A=10, B=11, ..., Z=35)
                predicted_char = chr(ord('A') + predicted_label - 10)
                letter_type = "Uppercase Letter"
            else:
                # Lowercase letters (a=36, b=37, ..., k=46)
                predicted_char = chr(ord('a') + predicted_label - 36)
                letter_type = "Lowercase Letter"
            result_text = f"Prediction: {predicted_char} ({letter_type}, Confidence: {confidence:.2f})"
            break
    else:
        result_text = "Could not determine character type"

    result_label.config(text=result_text)
    print(f"Final prediction: {result_text}")


# GUI setup
root = tk.Tk()
root.title("EMNIST/MNIST Character Predictor")

upload_button = Button(root, text="Upload Image", command=predict_image)
upload_button.pack(pady=5)

image_label = Label(root)  # Image display
image_label.pack(pady=5)

result_label = Label(root, text="Prediction: ", font=("Arial", 14))
result_label.pack(pady=5)

root.mainloop()
