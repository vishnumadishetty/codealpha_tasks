import tensorflow as tf
from data.download_emnist import load_mnist
from utils.preprocess import preprocess_image

model = tf.keras.models.load_model('emnist_cnn_model.h5')
_, test_ds = load_mnist()
test_ds = test_ds.map(preprocess_image).batch(64)
loss, acc = model.evaluate(test_ds)
print(f"Test Accuracy: {acc * 100:.2f}%")
