
import tensorflow_datasets as tfds
import tensorflow as tf
from models.cnn_model import create_cnn_model

# Load EMNIST 'balanced' and MNIST datasets
(emnist_train, emnist_test), emnist_info = tfds.load(
    'emnist/balanced',
    split=['train', 'test'],
    shuffle_files=True,
    as_supervised=True,
    with_info=True,
)

(mnist_train, mnist_test), _ = tfds.load(
    'mnist',
    split=['train', 'test'],
    shuffle_files=True,
    as_supervised=True,
    with_info=True
)

# Normalize and reshape


def preprocess(image, label):
    image = tf.cast(image, tf.float32) / 255.0
    image = tf.expand_dims(image, axis=-1)
    return image, label


# Apply preprocessing
emnist_train = emnist_train.map(preprocess)
emnist_test = emnist_test.map(preprocess)
mnist_train = mnist_train.map(preprocess)
mnist_test = mnist_test.map(preprocess)

# Combine EMNIST and MNIST datasets
train_ds = emnist_train.concatenate(mnist_train).cache().shuffle(
    20000).batch(64).prefetch(tf.data.AUTOTUNE)
test_ds = emnist_test.concatenate(
    mnist_test).batch(64).prefetch(tf.data.AUTOTUNE)

# Total number of classes in EMNIST 'balanced'
num_classes = 47

# Build and train model
model = create_cnn_model(num_classes=num_classes)
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(train_ds, epochs=15, validation_data=test_ds)

# Save model
model.save('emnist_cnn_model.h5')
